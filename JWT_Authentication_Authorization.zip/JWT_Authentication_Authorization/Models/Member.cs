﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace JWT_Authentication_Authorization.Models
{
    [Table("Members")]
    public class Member
    {

    
            [Key]
            public int Id { get; set; }  // Auto-increment primary key

            [Required]
            [MaxLength(100)]
            public string Name { get; set; }

            [Required]
            [EmailAddress]
            public string Email { get; set; }

            [Required]
            [MaxLength(100)]
            public string City { get; set; }

            [Range(18, 100)]
            public int Age { get; set; }

            [Phone]
            public string Phone_no { get; set; }
        
    }

}

