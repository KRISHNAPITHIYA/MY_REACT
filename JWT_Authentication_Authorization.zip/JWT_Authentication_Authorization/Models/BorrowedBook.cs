﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JWT_Authentication_Authorization.Models
{
    public class BorrowedBook
    {
        [Key]
        public int Id { get; set; }  // Primary Key

        [Required]
        public int MemberId { get; set; }  // Foreign Key from Members table

        [Required]
        public int BookId { get; set; }  // Foreign Key from Books table

        public DateTime BorrowDate { get; set; } = DateTime.UtcNow;

        public DateTime? ReturnDate { get; set; }  // Nullable: If null, book is not returned

        [ForeignKey("MemberId")]
        public Member Member { get; set; }

        [ForeignKey("BookId")]
        public Librarian Book { get; set; }
    }
}
