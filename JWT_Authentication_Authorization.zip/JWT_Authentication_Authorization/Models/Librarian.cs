﻿namespace JWT_Authentication_Authorization.Models
{
    public class Librarian
    {
        public int Id { get; set; }
        //public string Name { get; set; }
        public string Author { get; set; }
        public string  Title{ get; set; }
        public int Published_Year { get; set; }
        public string Subject { get; set; } 
        public int Amount { get; set; }
        public int Quantity { get; set; }

        public bool IsBorrowed { get; set; }
    }
}
