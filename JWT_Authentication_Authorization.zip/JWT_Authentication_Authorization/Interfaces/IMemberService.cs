﻿using JWT_Authentication_Authorization.Models;
using System.Collections.Generic;

namespace JWT_Authentication_Authorization.Interfaces
{
    public interface IMemberService
    {
        List<Member> GetMemberDetails();
        Member AddMember(Member member);
    }
}
