﻿using JWT_Authentication_Authorization.Models;
using System.Collections.Generic;

namespace JWT_Authentication_Authorization.Interfaces
{
    public interface ILibrarianService
    {
        List<Librarian> GetEmployeeDetails();  // Get all employees
        Librarian GetEmployeeById(int id);  // Get employee by ID
        Librarian AddEmployee(Librarian librarian);  // Add new employee
        void UpdateEmployee(Librarian librarian);  // Update employee details
        void DeleteEmployee(int id);  // Delete employee by ID
    }
}
