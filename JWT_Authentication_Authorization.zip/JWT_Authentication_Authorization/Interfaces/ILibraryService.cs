﻿using JWT_Authentication_Authorization.Context;

namespace JWT_Authentication_Authorization.Interfaces
{
  
        public interface ILibraryService
        {
            // Method to get all members with books (from stored procedure)
            Task<IEnumerable<LibraryDTO>> GetAllMembersWithBooksAsync();

            // Method to get books borrowed by a specific member
            Task<IEnumerable<LibraryDTO>> GetBooksByMemberAsync(int memberId);

            // Method to get all books with member details
            Task<IEnumerable<LibraryDTO>> GetAllBooksWithMembersAsync();

            // Method to get books by a specific criteria (subject and author)
            Task<IEnumerable<LibraryDTO>> GetBooksByCriteriaAsync(string subject, string author);




        Task<string> BorrowBookAsync(int memberId, int bookId);  // Borrow a book
        Task<string> ReturnBookAsync(int memberId, int bookId);  // Return a book
        Task<IEnumerable<LibraryDTO>> GetAllBorrowedBooksAsync();  // Get all borrowed books
        Task<IEnumerable<LibraryDTO>> GetBorrowedBooksByMemberAsync(int memberId);
    }



    }

