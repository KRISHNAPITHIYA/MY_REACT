﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JWT_Authentication_Authorization.Migrations
{
    /// <inheritdoc />
    public partial class AddPublished_YearToLibrarian : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Published_Year",
                table: "Librarians",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Published_Year",
                table: "Librarians");
        }
    }
}
