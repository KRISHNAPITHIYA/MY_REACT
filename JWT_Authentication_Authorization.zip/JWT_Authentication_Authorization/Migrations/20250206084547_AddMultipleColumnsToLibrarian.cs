﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JWT_Authentication_Authorization.Migrations
{
    /// <inheritdoc />
    public partial class AddMultipleColumnsToLibrarian : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Name",
                table: "Librarians",
                newName: "Subject");

            migrationBuilder.AddColumn<int>(
                name: "Amount",
                table: "Librarians",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "Librarians",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Amount",
                table: "Librarians");

            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "Librarians");

            migrationBuilder.RenameColumn(
                name: "Subject",
                table: "Librarians",
                newName: "Name");
        }
    }
}
