﻿namespace JWT_Authentication_Authorization.Context
{
    public class LibraryDTO
    {
          // Member properties
            public int MemberId { get; set; }            // Member's ID
            public string MemberName { get; set; }       // Member's name
            public string MemberEmail { get; set; }      // Member's email
            public string MemberCity { get; set; }       // Member's city
            public int MemberAge { get; set; }           // Member's age
            public string MemberPhoneNo { get; set; }    // Member's phone number

            // Book (Librarians) properties
            public int BookId { get; set; }              // Book ID
            public string BookSubject { get; set; }      // Book subject
            public string BookAuthor { get; set; }       // Book author
            public string BookTitle { get; set; }        // Book title
            public int BookPublishedYear { get; set; }   // Book published year
            public decimal BookAmount { get; set; }      // Book price/amount
            public int BookQuantity { get; set; }        // Book quantity in library

        public bool IsBorrowed { get; set; }         // Indicates if book is borrowed
        public DateTime? BorrowedDate { get; set; }  // Borrowed date (nullable)
        public DateTime? ReturnDate { get; set; }
    }

    }

