﻿using JWT_Authentication_Authorization.Interfaces;
using JWT_Authentication_Authorization.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace JWT_Authentication_Authorization.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibrarianController : ControllerBase
    {
        private readonly ILibrarianService _librarianService;

        // Constructor to inject the service
        public LibrarianController(ILibrarianService librarianService)
        {
            _librarianService = librarianService;
        }

        // GET: api/librarian
        // Only User and Admin can access this
        [HttpGet]
        [Authorize(Roles = "User,Admin")]
        public List<Librarian> GetLibrarians()
        {
            return _librarianService.GetEmployeeDetails();
        }

        // GET: api/librarian/{id}
        // Only User and Admin can access this
        [HttpGet("{id}")]
        [Authorize(Roles = "User,Admin")]
        public ActionResult<Librarian> GetLibrarianById(int id)
        {
            var librarian = _librarianService.GetEmployeeById(id);
            if (librarian == null)
            {
                return NotFound();
            }
            return Ok(librarian);
        }

        // POST: api/librarian
        // Only Admin can access this
        [HttpPost]
        [Authorize(Roles = "Admin")]
        public ActionResult<Librarian> AddLibrarian([FromBody] Librarian librarian)
        {
            if (librarian == null)
            {
                return BadRequest();
            }

            var createdLibrarian = _librarianService.AddEmployee(librarian);

            return CreatedAtAction(nameof(GetLibrarianById), new { id = createdLibrarian.Id }, createdLibrarian);
        }

        // PUT: api/librarian/{id}
        // Only Admin can access this
        [HttpPut("{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult UpdateLibrarian(int id, [FromBody] Librarian librarian)
        {
            if (librarian == null || librarian.Id != id)
            {
                return BadRequest();
            }

            var existingLibrarian = _librarianService.GetEmployeeById(id);
            if (existingLibrarian == null)
            {
                return NotFound();
            }

            _librarianService.UpdateEmployee(librarian);

            return NoContent(); // Success response with no content
        }

        // DELETE: api/librarian/{id}
        // Only Admin can access this
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public IActionResult DeleteLibrarian(int id)
        {
            var librarian = _librarianService.GetEmployeeById(id);
            if (librarian == null)
            {
                return NotFound();
            }

            _librarianService.DeleteEmployee(id);
            return NoContent(); // Success response with no content
        }
    }
}
