﻿using JWT_Authentication_Authorization.Context;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using JWT_Authentication_Authorization.Interfaces;
using System.Threading.Tasks;

namespace JWT_Authentication_Authorization.Controllers
{
    [Route("api/[controller]")]
    [Authorize]
    [ApiController]
    public class LibraryController : ControllerBase
    {
        private readonly ILibraryService _libraryService;

        public LibraryController(ILibraryService libraryService)
        {
            _libraryService = libraryService;
        }

        [HttpGet("allMembers-with-books")]
        public async Task<IActionResult> GetAllMembersWithBooks()
        {
            var result = await _libraryService.GetAllMembersWithBooksAsync();
            return Ok(result);
        }

        [HttpGet("member-books/{memberId}")]
        public async Task<IActionResult> GetBooksByMember(int memberId)
        {
            var result = await _libraryService.GetBooksByMemberAsync(memberId);
            return Ok(result);
        }

        [HttpGet("allBooks-with-MemberDetails")]
        public async Task<IActionResult> GetAllBooksWithMembers()
        {
            var result = await _libraryService.GetAllBooksWithMembersAsync();
            return Ok(result);
        }

        [HttpGet("booksby-subject-and-Author-with-MemberData")]
        public async Task<IActionResult> GetBooksByCriteria([FromQuery] string subject, [FromQuery] string author)
        {
            var result = await _libraryService.GetBooksByCriteriaAsync(subject, author);
            return Ok(result);
        }

        [HttpPost("borrow-book")]
        public async Task<IActionResult> BorrowBook([FromQuery] int memberId, [FromQuery] int bookId)
        {
            var result = await _libraryService.BorrowBookAsync(memberId, bookId);
            return Ok(new { message = result });
        }

        [HttpPost("return-book")]
        public async Task<IActionResult> ReturnBook([FromQuery] int memberId, [FromQuery] int bookId)
        {
            var result = await _libraryService.ReturnBookAsync(memberId, bookId);
            return Ok(new { message = result });
        }

        [HttpGet("borrowed-books")]
        public async Task<IActionResult> GetAllBorrowedBooks()
        {
            var books = await _libraryService.GetAllBorrowedBooksAsync();
            return Ok(books);
        }

        [HttpGet("borrowed-books/{memberId}")]
        public async Task<IActionResult> GetBorrowedBooksByMember(int memberId)
        {
            var books = await _libraryService.GetBorrowedBooksByMemberAsync(memberId);
            return Ok(books);
        }
    }
}







































//using JWT_Authentication_Authorization.Context;
//using System.Data;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Data.SqlClient;
//using JWT_Authentication_Authorization.Interfaces;
//using Microsoft.AspNetCore.Authorization;
//using JWT_Authentication_Authorization.Services;

//namespace JWT_Authentication_Authorization.Controllers
//{

//    [Route("api/[controller]")]
//    [Authorize]
//    [ApiController]

//    public class LibraryController : ControllerBase
//    {
//        private readonly ILibraryService _libraryservice;

//        public LibraryController(ILibraryService libraryRepository)
//        {
//            _libraryservice = libraryRepository;
//        }

//        [HttpGet("allMembers-with-books")]
//        public async Task<IActionResult> GetAllMembersWithBooks()
//        {
//            var result = await _libraryservice.GetAllMembersWithBooksAsync();
//            return Ok(result);  // Return the result to the client
//        }


//        [HttpGet("member-books/{memberId}")]
//        public async Task<IActionResult> GetBooksByMember(int memberId)
//        {
//            var result = await _libraryservice.GetBooksByMemberAsync(memberId);
//            return Ok(result);
//        }

//        [HttpGet("allBooks-with-MemberDetails")]
//        public async Task<IActionResult> GetAllBooksWithMembers()
//        {
//            var result = await _libraryservice.GetAllBooksWithMembersAsync();
//            return Ok(result);
//        }

//        [HttpGet("booksby-subject-and-Author-with-MemberData")]
//        public async Task<IActionResult> GetBooksByCriteria([FromQuery] string subject, [FromQuery] string author)
//        {
//            var result = await _libraryservice.GetBooksByCriteriaAsync(subject, author);
//            return Ok(result);
//        }


//    }
//}

