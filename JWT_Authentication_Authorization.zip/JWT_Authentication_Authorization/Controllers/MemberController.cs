﻿using JWT_Authentication_Authorization.Interfaces;
using JWT_Authentication_Authorization.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace JWT_Authentication_Authorization.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly IMemberService _memberService;

       
        public MemberController(IMemberService memberService)
        {
            _memberService = memberService;
        }

        
        [HttpGet]
        [Authorize(Roles = "User,Admin")]  // Allows only User and Admin roles to access
        public List<Member> GetMembers()
        {
            return _memberService.GetMemberDetails();
        }

        
        [HttpPost]
        [Authorize]  // Only authenticated users can add members
        public Member AddMember([FromBody] Member member)
        {
            var newMember = _memberService.AddMember(member);
            return newMember;
        }

    }
}
