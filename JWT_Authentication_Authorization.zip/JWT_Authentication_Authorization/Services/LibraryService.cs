﻿using JWT_Authentication_Authorization.Context;
using JWT_Authentication_Authorization.Interfaces;
using Microsoft.Data.SqlClient;
using System.Data;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace JWT_Authentication_Authorization.Services
{
    public class LibraryService : ILibraryService
    {
        private readonly IDbConnection _dbConnection;

        public LibraryService(IConfiguration configuration)
        {
            _dbConnection = new SqlConnection(configuration.GetConnectionString("Database"));
        }

        // Get all members with books
        public async Task<IEnumerable<LibraryDTO>> GetAllMembersWithBooksAsync()
        {
            var query = "EXEC GetAllMembersWithBooks";
            return await _dbConnection.QueryAsync<LibraryDTO>(query);
        }

        // Get books borrowed by a specific member
        public async Task<IEnumerable<LibraryDTO>> GetBooksByMemberAsync(int memberId)
        {
            var query = "EXEC GetBooksByMember @MemberId";
            return await _dbConnection.QueryAsync<LibraryDTO>(query, new { MemberId = memberId });
        }

        // Get all books with member details
        public async Task<IEnumerable<LibraryDTO>> GetAllBooksWithMembersAsync()
        {
            var query = "EXEC GetAllBooksWithMembers";
            return await _dbConnection.QueryAsync<LibraryDTO>(query);
        }

        // Get books by subject and author with member data
        public async Task<IEnumerable<LibraryDTO>> GetBooksByCriteriaAsync(string subject, string author)
        {
            var query = "EXEC GetBooksByCriteria @Subject, @Author";
            return await _dbConnection.QueryAsync<LibraryDTO>(query, new { Subject = subject, Author = author });
        }

        // Borrow a book with improved logging and validation
        public async Task<string> BorrowBookAsync(int memberId, int bookId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@MemberId", memberId);
            parameters.Add("@BookId", bookId);
            parameters.Add("@ResultMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

            int rowsAffected = await _dbConnection.ExecuteAsync("BorrowBook", parameters, commandType: CommandType.StoredProcedure);

            // Debugging Log
            Console.WriteLine($"Executing BorrowBook SP: MemberId={memberId}, BookId={bookId}");
            Console.WriteLine($"Rows Affected: {rowsAffected}");

            string resultMessage = parameters.Get<string>("@ResultMessage");
            return rowsAffected > 0 ? resultMessage : "Failed to borrow the book.";
        }

        // Return a book with improved logging and validation
        public async Task<string> ReturnBookAsync(int memberId, int bookId)
        {
            var parameters = new DynamicParameters();
            parameters.Add("@MemberId", memberId);
            parameters.Add("@BookId", bookId);
            parameters.Add("@ResultMessage", dbType: DbType.String, direction: ParameterDirection.Output, size: 255);

            int rowsAffected = await _dbConnection.ExecuteAsync("ReturnBook", parameters, commandType: CommandType.StoredProcedure);

            // Debugging Log
            Console.WriteLine($"Executing ReturnBook SP: MemberId={memberId}, BookId={bookId}");
            Console.WriteLine($"Rows Affected: {rowsAffected}");

            string resultMessage = parameters.Get<string>("@ResultMessage");
            return rowsAffected > 0 ? resultMessage : "Failed to return the book.";
        }

        // Get all borrowed books
        public async Task<IEnumerable<LibraryDTO>> GetAllBorrowedBooksAsync()
        {
            return await _dbConnection.QueryAsync<LibraryDTO>("EXEC GetAllBorrowedBooks");
        }

        // Get borrowed books by a specific member
        public async Task<IEnumerable<LibraryDTO>> GetBorrowedBooksByMemberAsync(int memberId)
        {
            var query = "EXEC GetBorrowedBooksByMember @MemberId";
            return await _dbConnection.QueryAsync<LibraryDTO>(query, new { MemberId = memberId });
        }
    }
}













































































































//using JWT_Authentication_Authorization.Context;
//using JWT_Authentication_Authorization.Interfaces;
//using Microsoft.Data.SqlClient;
//using System.Data;
//using Dapper;
//using Microsoft.Extensions.Configuration;

//namespace JWT_Authentication_Authorization.Services
//{
//    public class LibraryService : ILibraryService
//    {
//        private readonly IDbConnection _dbConnection;

//        public LibraryService(IConfiguration configuration)
//        {
//            _dbConnection = new SqlConnection(configuration.GetConnectionString("Database"));
//        }

//        // Get all members with books
//        public async Task<IEnumerable<LibraryDTO>> GetAllMembersWithBooksAsync()
//        {
//            var query = "EXEC GetAllMembersWithBooks";
//            return await _dbConnection.QueryAsync<LibraryDTO>(query);
//        }

//        // Get books borrowed by a specific member
//        public async Task<IEnumerable<LibraryDTO>> GetBooksByMemberAsync(int memberId)
//        {
//            var query = "EXEC GetBooksByMember @MemberId";
//            return await _dbConnection.QueryAsync<LibraryDTO>(query, new { MemberId = memberId });
//        }

//        // Get all books with member details
//        public async Task<IEnumerable<LibraryDTO>> GetAllBooksWithMembersAsync()
//        {
//            var query = "EXEC GetAllBooksWithMembers";
//            return await _dbConnection.QueryAsync<LibraryDTO>(query);
//        }

//        // Get books by subject and author with member data
//        public async Task<IEnumerable<LibraryDTO>> GetBooksByCriteriaAsync(string subject, string author)
//        {
//            var query = "EXEC GetBooksByCriteria @Subject, @Author";
//            return await _dbConnection.QueryAsync<LibraryDTO>(query, new { Subject = subject, Author = author });
//        }

//        // Borrow a book
//        public async Task<string> BorrowBookAsync(int memberId, int bookId)
//        {
//            var parameters = new DynamicParameters();
//            parameters.Add("@MemberId", memberId);
//            parameters.Add("@BookId", bookId);

//            await _dbConnection.ExecuteAsync("BorrowBook", parameters, commandType: CommandType.StoredProcedure);
//            return "Book borrowed successfully.";
//        }

//        // Return a book
//        public async Task<string> ReturnBookAsync(int memberId, int bookId)
//        {
//            var parameters = new DynamicParameters();
//            parameters.Add("@MemberId", memberId);
//            parameters.Add("@BookId", bookId);

//            await _dbConnection.ExecuteAsync("ReturnBook", parameters, commandType: CommandType.StoredProcedure);
//            return "Book returned successfully.";
//        }

//        // Get all borrowed books
//        public async Task<IEnumerable<LibraryDTO>> GetAllBorrowedBooksAsync()
//        {
//            return await _dbConnection.QueryAsync<LibraryDTO>("EXEC GetAllBorrowedBooks");
//        }

//        // Get borrowed books by a specific member
//        public async Task<IEnumerable<LibraryDTO>> GetBorrowedBooksByMemberAsync(int memberId)
//        {
//            var query = "EXEC GetBorrowedBooksByMember @MemberId";
//            return await _dbConnection.QueryAsync<LibraryDTO>(query, new { MemberId = memberId });
//        }
//    }
//}








































//using JWT_Authentication_Authorization.Context;
//using JWT_Authentication_Authorization.Interfaces;
//using Microsoft.Data.SqlClient;
//using System.Data;
//using Dapper;

//namespace JWT_Authentication_Authorization.Services
//{

//        public class LibraryService : ILibraryService
//        {
//            private readonly IDbConnection _dbConnection;

//            public LibraryService(IConfiguration configuration)
//            {
//                _dbConnection = new SqlConnection(configuration.GetConnectionString("Database"));
//            }

//            // Get all members with books
//            public async Task<IEnumerable<LibraryDTO>> GetAllMembersWithBooksAsync()
//            {
//                var query = "EXEC GetAllMembersWithBooks";  // Call the stored procedure
//                return await _dbConnection.QueryAsync<LibraryDTO>(query);  // Map results to LibraryDto
//            }

//            // Get books borrowed by a specific member
//            public async Task<IEnumerable<LibraryDTO>> GetBooksByMemberAsync(int memberId)
//            {
//                var query = "EXEC GetBooksByMember @MemberId";
//                return await _dbConnection.QueryAsync<LibraryDTO>(query, new { MemberId = memberId });
//            }

//            // Get all books with member details
//            public async Task<IEnumerable<LibraryDTO>> GetAllBooksWithMembersAsync()
//            {
//                var query = "EXEC GetAllBooksWithMembers";
//                return await _dbConnection.QueryAsync<LibraryDTO>(query);
//            }

//            // Get books by subject and author with member data
//            public async Task<IEnumerable<LibraryDTO>> GetBooksByCriteriaAsync(string subject, string author)
//            {
//                var query = "EXEC GetBooksByCriteria @Subject, @Author";
//                return await _dbConnection.QueryAsync<LibraryDTO>(query, new { Subject = subject, Author = author });
//            }

//        }

//    }

