﻿using JWT_Authentication_Authorization.Context;
using JWT_Authentication_Authorization.Interfaces;
using JWT_Authentication_Authorization.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace JWT_Authentication_Authorization.Services
{
    public class BookService : ILibrarianService
    {
        private readonly JwtContext _context;

        public BookService(JwtContext context)
        {
            _context = context;
        }

        // Method to get all librarians, using AsNoTracking for read-only access
        public List<Librarian> GetEmployeeDetails()
        {
            return _context.Librarians.AsNoTracking().ToList();  // Using AsNoTracking to avoid unnecessary tracking
        }

        // Method to get a librarian by ID, using AsNoTracking for read-only access
        public Librarian GetEmployeeById(int id)
        {
            return _context.Librarians.AsNoTracking().FirstOrDefault(l => l.Id == id);  // Using AsNoTracking for read-only access
        }

        // Method to add a new librarian
        public Librarian AddEmployee(Librarian librarian)
        {
            // If an existing librarian with the same ID is being tracked, we need to detach it
            var existingLibrarian = _context.Librarians.Local.FirstOrDefault(l => l.Id == librarian.Id);
            if (existingLibrarian != null)
            {
                _context.Entry(existingLibrarian).State = EntityState.Detached;  // Detach the tracked entity
            }

            // Add the new librarian and save changes
            _context.Librarians.Add(librarian);
            _context.SaveChanges();
            return librarian;  // Return the newly created librarian
        }

        // Method to update an existing librarian
        public void UpdateEmployee(Librarian librarian)
        {
            // If the librarian entity is already tracked, we will update it
            var existingLibrarian = _context.Librarians.Local.FirstOrDefault(l => l.Id == librarian.Id);
            if (existingLibrarian != null)
            {
                _context.Entry(existingLibrarian).State = EntityState.Detached;  // Detach the tracked entity
            }

            // Update the librarian entity in the context
            _context.Librarians.Update(librarian);
            _context.SaveChanges();
        }

        // Method to delete a librarian by ID
        public void DeleteEmployee(int id)
        {
            var librarian = _context.Librarians.Find(id);
            if (librarian != null)
            {
                _context.Librarians.Remove(librarian);
                _context.SaveChanges();
            }
        }

    }
}




































//using JWT_Authentication_Authorization.Context;
//using JWT_Authentication_Authorization.Interfaces;
//using JWT_Authentication_Authorization.Models;
//using System.Collections.Generic;
//using System.Linq;

//namespace JWT_Authentication_Authorization.Services
//{
//    public class LibrarianService : ILibrarianService
//    {
//        private readonly JwtContext _context;

//        public LibrarianService(JwtContext context)
//        {
//            _context = context;
//        }

//        public List<Librarian> GetEmployeeDetails()
//        {
//            return _context.Librarians.ToList();  // Get all librarians
//        }

//        public Librarian GetEmployeeById(int id)
//        {
//            return _context.Librarians.FirstOrDefault(l => l.Id == id);  // Get a librarian by ID
//        }

//        public Librarian AddEmployee(Librarian librarian)
//        {
//            _context.Librarians.Add(librarian);
//            _context.SaveChanges();
//            return librarian;  // Return the newly created librarian
//        }

//        public void UpdateEmployee(Librarian librarian)
//        {
//            _context.Librarians.Update(librarian);
//            _context.SaveChanges();
//        }

//        public void DeleteEmployee(int id)
//        {
//            var librarian = _context.Librarians.Find(id);
//            if (librarian != null)
//            {
//                _context.Librarians.Remove(librarian);
//                _context.SaveChanges();
//            }
//        }
//    }
//}
