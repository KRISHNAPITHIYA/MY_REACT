﻿using JWT_Authentication_Authorization.Context;
using JWT_Authentication_Authorization.Interfaces;
using JWT_Authentication_Authorization.Models;
using System.Collections.Generic;

namespace JWT_Authentication_Authorization.Services
{
    public class MemberService : IMemberService
    {
        private readonly JwtContext _context;

        public MemberService(JwtContext context)
        {
            _context = context;
        }

        public List<Member> GetMemberDetails()
        {
            return _context.Members.ToList();  // Fetching member details from the database
        }

        public Member AddMember(Member member)
        {
            _context.Members.Add(member);  // Adding a new member to the database
            _context.SaveChanges();
            return member;
        }

    }
}
